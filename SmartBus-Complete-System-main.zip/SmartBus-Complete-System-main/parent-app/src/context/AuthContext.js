import React, { createContext, useContext, useEffect, useState } from "react";
import { onAuthChange, getParentProfile } from "../services/firebaseService";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [parentProfile, setParentProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthChange(async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          const profile = await getParentProfile(firebaseUser.uid);
          setParentProfile(profile);
        } catch (err) {
          console.warn("Failed to load parent profile:", err.message);
        }
      } else {
        setParentProfile(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  const refreshProfile = async () => {
    if (user) {
      const profile = await getParentProfile(user.uid);
      setParentProfile(profile);
    }
  };

  return (
    <AuthContext.Provider value={{ user, parentProfile, loading, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
