import React, { useEffect, useState } from "react";
import {
  View, Text, FlatList, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator, RefreshControl,
} from "react-native";
import { useAuth } from "../../context/AuthContext";
import { getAssignedBus, subscribeToStudentsForBus, endTrip } from "../../services/firebaseService";

export default function HomeScreen({ navigation }) {
  const { user, driverProfile } = useAuth();
  const [bus, setBus] = useState(null);
  const [students, setStudents] = useState([]);
  const [loadingBus, setLoadingBus] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [endingTrip, setEndingTrip] = useState(false);

  const loadBus = async () => {
    console.log("[HomeScreen] loadBus called");
    console.log("[HomeScreen] user.uid:", user?.uid);
    try {
      const assignedBus = await getAssignedBus(user.uid);
      console.log("[HomeScreen] getAssignedBus returned:", assignedBus ? `bus id=${assignedBus.id}` : "null");
      setBus(assignedBus);
      return assignedBus;
    } catch (err) {
      console.error("[HomeScreen] loadBus error:", err.message);
      Alert.alert("Error", "Could not load your assigned bus.");
      return null;
    } finally {
      setLoadingBus(false);
    }
  };

  useEffect(() => {
    let unsub;
    loadBus().then((assignedBus) => {
      if (assignedBus) {
        unsub = subscribeToStudentsForBus(assignedBus.id, setStudents);
      }
    });
    return () => unsub && unsub();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadBus();
    setRefreshing(false);
  };

  const handleEndTrip = () => {
    if (!bus) {
      Alert.alert("No Bus", "You don't have an assigned bus to end a trip for.");
      return;
    }
    Alert.alert(
      "End Trip",
      "Are you sure you want to end this trip?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "End Trip",
          style: "destructive",
          onPress: async () => {
            setEndingTrip(true);
            try {
              const summary = await endTrip({
                busId: bus.id,
                driverId: user.uid,
                totalStudents: students.length,
              });
              Alert.alert(
                "✅ Trip Completed!",
                `Total Students: ${summary.totalStudents}\nPresent: ${summary.presentCount}\nAbsent: ${summary.absentCount}\nTrip ended at: ${summary.endTime}`
              );
            } catch (err) {
              console.error("[HomeScreen] endTrip error:", err.message);
              Alert.alert("Error", "Could not end the trip. Please try again.");
            } finally {
              setEndingTrip(false);
            }
          },
        },
      ]
    );
  };

  if (loadingBus) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#1D4ED8" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.greeting}>Hello, {driverProfile?.name || "Driver"} 👋</Text>
        {bus ? (
          <View style={styles.busCard}>
            <Text style={styles.busTitle}>🚌 Bus {bus.number}</Text>
            <Text style={styles.busInfo}>Plate: {bus.plateNumber || "N/A"}</Text>
            <Text style={styles.busInfo}>Capacity: {bus.capacity || "N/A"} students</Text>
            <Text style={styles.busInfo}>Students Assigned: {students.length}</Text>
          </View>
        ) : (
          <View style={styles.noBusCard}>
            <Text style={styles.noBusText}>No bus assigned yet.</Text>
            <Text style={styles.noBusSubText}>Contact admin for bus assignment.</Text>
          </View>
        )}
      </View>

      <View style={styles.actionsGrid}>
        <View style={styles.actionRow}>
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: "#1D4ED8" }]}
            onPress={() => navigation.navigate("QRScanner")}
          >
            <Text style={styles.actionEmoji}>📷</Text>
            <Text style={styles.actionText}>Scan QR</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: "#059669" }]}
            onPress={() => navigation.navigate("GPSTracking")}
          >
            <Text style={styles.actionEmoji}>📍</Text>
            <Text style={styles.actionText}>GPS Track</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.actionRow}>
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: "#DC2626" }]}
            onPress={() => navigation.navigate("Alerts")}
          >
            <Text style={styles.actionEmoji}>🔔</Text>
            <Text style={styles.actionText}>Alerts</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionBtn, { backgroundColor: "#7C3AED" }]}
            onPress={() => navigation.navigate("AttendanceHistory")}
          >
            <Text style={styles.actionEmoji}>📋</Text>
            <Text style={styles.actionText}>History</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={[styles.actionBtnFull, { backgroundColor: "#DC2626" }, endingTrip && styles.actionBtnDisabled]}
          onPress={handleEndTrip}
          disabled={endingTrip}
        >
          <Text style={styles.actionEmoji}>{endingTrip ? "⏳" : "🏁"}</Text>
          <Text style={styles.actionText}>{endingTrip ? "Ending..." : "End Trip"}</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>Students ({students.length})</Text>
      <FlatList
        data={students}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No students assigned to this bus.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.studentCard}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{item.name?.[0]?.toUpperCase() || "?"}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.studentName}>{item.name}</Text>
              <Text style={styles.studentRoll}>Roll: {item.rollNumber}</Text>
              <Text style={styles.studentGrade}>Grade: {item.grade || "N/A"}</Text>
            </View>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F3F4F6" },
  centered: { flex: 1, justifyContent: "center", alignItems: "center" },
  header: { backgroundColor: "#1D4ED8", padding: 20, paddingTop: 50 },
  greeting: { color: "#fff", fontSize: 20, fontWeight: "bold", marginBottom: 12 },
  busCard: { backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 12, padding: 14 },
  busTitle: { color: "#fff", fontSize: 18, fontWeight: "bold", marginBottom: 6 },
  busInfo: { color: "rgba(255,255,255,0.85)", fontSize: 14, marginBottom: 2 },
  noBusCard: { backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 12, padding: 14, alignItems: "center" },
  noBusText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
  noBusSubText: { color: "rgba(255,255,255,0.75)", fontSize: 13, marginTop: 4 },
  actionsGrid: { padding: 16, backgroundColor: "#fff", borderBottomWidth: 1, borderBottomColor: "#E5E7EB", gap: 10 },
  actionRow: { flexDirection: "row", gap: 10, justifyContent: "space-between" },
  actionBtn: { flex: 1, alignItems: "center", borderRadius: 12, paddingVertical: 14, paddingHorizontal: 12, elevation: 2, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2 },
  actionBtnFull: { width: "100%", alignItems: "center", borderRadius: 12, paddingVertical: 14, paddingHorizontal: 12, elevation: 2, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2 },
  actionBtnDisabled: { opacity: 0.6 },
  actionEmoji: { fontSize: 28, marginBottom: 6 },
  actionText: { color: "#fff", fontSize: 13, fontWeight: "600", textAlign: "center" },
  sectionTitle: { fontSize: 16, fontWeight: "bold", color: "#374151", padding: 16, paddingBottom: 8 },
  studentCard: { flexDirection: "row", alignItems: "center", backgroundColor: "#fff", marginHorizontal: 16, marginBottom: 8, borderRadius: 12, padding: 14 },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: "#DBEAFE", justifyContent: "center", alignItems: "center", marginRight: 12 },
  avatarText: { fontSize: 18, fontWeight: "bold", color: "#1D4ED8" },
  studentName: { fontSize: 15, fontWeight: "600", color: "#1F2937" },
  studentRoll: { fontSize: 13, color: "#6B7280", marginTop: 2 },
  studentGrade: { fontSize: 13, color: "#6B7280" },
  empty: { alignItems: "center", paddingVertical: 40 },
  emptyText: { color: "#9CA3AF", fontSize: 15 },
});
